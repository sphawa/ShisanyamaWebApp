package com.shisanyama.shisanyamaWebApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShisanyamaWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShisanyamaWebAppApplication.class, args);
	}

}
